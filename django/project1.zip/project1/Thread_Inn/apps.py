from django.apps import AppConfig


class ThreadInnConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Thread_Inn'
